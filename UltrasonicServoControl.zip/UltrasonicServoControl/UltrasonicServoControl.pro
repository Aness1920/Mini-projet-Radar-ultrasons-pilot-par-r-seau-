QT       += core gui
greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

TARGET = UltrasonicServoControl
TEMPLATE = app

# Sources en UTF-8 (accents dans les textes) avec MSVC
msvc: QMAKE_CXXFLAGS += /utf-8
msvc: QMAKE_CFLAGS += /utf-8

# Le module réseau udpnet.c utilise Winsock sous Windows
win32: LIBS += -lws2_32

SOURCES += \
    main.cpp \
    dialog.cpp \
    radarwidget.cpp \
    udpworker.cpp \
    udpnet.c

HEADERS += \
    dialog.h \
    radarwidget.h \
    udpworker.h \
    udpnet.h

FORMS += \
    dialog.ui

# Règles de déploiement par défaut
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target
