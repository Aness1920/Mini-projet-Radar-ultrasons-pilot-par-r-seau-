#include "radarwidget.h"

#include <QPainter>
#include <QtMath>
#include <cmath>

RadarWidget::RadarWidget(QWidget *parent)
    : QWidget(parent)
{
}

void RadarWidget::setMaxRange(double cm)
{
    m_maxRange = qMax(1.0, cm);
    update();
}

void RadarWidget::setCurrentAngle(int angleDeg)
{
    m_angle = qBound(0, angleDeg, 180);
    update();
}

void RadarWidget::addPoint(int angleDeg, double distanceCm)
{
    m_echoes.insert(qBound(0, angleDeg, 180), distanceCm);
    update();
}

void RadarWidget::clearPoints()
{
    m_echoes.clear();
    update();
}

void RadarWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);
    p.fillRect(rect(), QColor(6, 18, 10));

    const double margin = 30.0;
    const double r = qMin((width() - 2 * margin) / 2.0, height() - 2 * margin);
    if (r < 30.0)
        return;
    const QPointF c(width() / 2.0, height() - margin);   // centre = position du capteur

    auto polar = [&](double angleDeg, double radius) {
        const double a = qDegreesToRadians(angleDeg);
        return QPointF(c.x() + radius * std::cos(a), c.y() - radius * std::sin(a));
    };

    // --- Grille : 4 arcs de distance + rayons tous les 30° ---
    p.setPen(QPen(QColor(30, 110, 60), 1));
    p.setBrush(Qt::NoBrush);
    for (int i = 1; i <= 4; ++i) {
        const double rad = r * i / 4.0;
        p.drawArc(QRectF(c.x() - rad, c.y() - rad, 2 * rad, 2 * rad), 0, 180 * 16);
    }
    for (int a = 0; a <= 180; a += 30)
        p.drawLine(c, polar(a, r));

    // --- Graduations ---
    QFont f = font();
    f.setPointSize(8);
    p.setFont(f);
    p.setPen(QColor(120, 200, 150));
    for (int i = 1; i <= 4; ++i) {
        const QString txt = QStringLiteral("%1 cm").arg(m_maxRange * i / 4.0, 0, 'f', 0);
        p.drawText(QRectF(c.x() + r * i / 4.0 - 25, c.y() + 4, 50, 16), Qt::AlignCenter, txt);
    }
    for (int a = 0; a <= 180; a += 30) {
        const QPointF t = polar(a, r + 16);
        p.drawText(QRectF(t.x() - 16, t.y() - 8, 32, 16), Qt::AlignCenter,
                   QStringLiteral("%1°").arg(a));
    }

    // --- Profil mesuré (relie les points voisins) ---
    p.setPen(QPen(QColor(255, 140, 60, 170), 1.5));
    QPointF prev;
    bool hasPrev = false;
    for (auto it = m_echoes.constBegin(); it != m_echoes.constEnd(); ++it) {
        const double d = it.value();
        if (d < 0 || d > m_maxRange) {      // pas d'écho / hors portée
            hasPrev = false;
            continue;
        }
        const QPointF pt = polar(it.key(), r * d / m_maxRange);
        if (hasPrev)
            p.drawLine(prev, pt);
        prev = pt;
        hasPrev = true;
    }

    // --- Points de mesure ---
    p.setPen(Qt::NoPen);
    p.setBrush(QColor(255, 90, 60));
    for (auto it = m_echoes.constBegin(); it != m_echoes.constEnd(); ++it) {
        const double d = it.value();
        if (d < 0 || d > m_maxRange)
            continue;
        p.drawEllipse(polar(it.key(), r * d / m_maxRange), 4.0, 4.0);
    }

    // --- Position courante du servo ---
    p.setPen(QPen(QColor(120, 255, 160), 2));
    p.drawLine(c, polar(m_angle, r));
    p.setBrush(QColor(120, 255, 160));
    p.drawEllipse(c, 4.0, 4.0);
}
