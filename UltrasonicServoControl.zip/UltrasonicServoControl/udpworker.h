#ifndef UDPWORKER_H
#define UDPWORKER_H

#include <QObject>
#include <QString>

#include "udpnet.h"

/*
 * Objet de travail exécuté dans un QThread : il appelle le module réseau C
 * (bloquant) sans jamais figer l'interface graphique.
 *
 * Le GUI émet un signal relié à execute(), puis reçoit finished() une fois
 * la réponse arrivée, le délai écoulé (après tous les essais) ou l'annulation.
 */
class UdpWorker : public QObject
{
    Q_OBJECT

public:
    explicit UdpWorker(QObject *parent = nullptr);
    ~UdpWorker() override;

    // Appelables depuis le thread de l'interface :
    void cancel();     // interrompt la requête en cours
    void shutdown();   // refuse toute nouvelle requête et interrompt la requête en cours

public slots:
    void execute(int id, const QString &ip, quint16 port, const QString &command,
                 int timeoutMs, int tries);

signals:
    // status : UDP_OK ou code d'erreur négatif du module C
    void finished(int id, int status, const QString &reply, const QString &error, int attempts);

private:
    void closeClient();

    UdpClient *m_client = nullptr;
    QString m_ip;
    quint16 m_port = 0;
    volatile int m_cancel = 0;
    volatile int m_shutdown = 0;
};

#endif // UDPWORKER_H
