#include "dialog.h"
#include "ui_dialog.h"

#include "udpnet.h"
#include "udpworker.h"

#include <QPushButton>
#include <QSignalBlocker>
#include <QStringList>
#include <QTableWidgetItem>
#include <QTime>

// ---------------------------------------------------------------------------
// Protocole de la carte (ASCII, un message par datagramme UDP, fin de ligne '\n')
//
//   ANGLE <a>                  ->  OK   |   ERR <motif>
//   DIST                       ->  DIST <cm>   |   DIST TIMEOUT (aucun écho)
//   SCAN <début> <fin> <pas>   ->  "<angle> <cm>" par ligne, puis END (un seul datagramme)
//
// UDP peut perdre des datagrammes : le module réseau C attend la réponse
// (délai d'attente réglable) puis renvoie la commande (nombre d'essais réglable).
// ---------------------------------------------------------------------------

namespace {
constexpr int kMaxScanPoints = 100;   // la réponse à SCAN doit tenir dans un seul datagramme
}

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);
    setWindowFlags(windowFlags() | Qt::WindowMinimizeButtonHint | Qt::WindowMaximizeButtonHint);

    // Evite que la touche Entrée dans un champ déclenche un bouton au hasard
    const auto buttons = findChildren<QPushButton *>();
    for (QPushButton *b : buttons)
        b->setAutoDefault(false);

    ui->plainTextEditLog->setMaximumBlockCount(500);
    ui->radarWidget->setMaxRange(ui->spinBoxRange->value());
    ui->radarWidget->setCurrentAngle(ui->sliderAngle->value());

    m_liveTimer.setSingleShot(true);
    m_liveTimer.setInterval(40);
    m_pollTimer.setInterval(ui->spinBoxPeriod->value());

    // --- Thread réseau : le module C (bloquant) ne tourne jamais dans le thread de l'interface ---
    m_worker = new UdpWorker;
    m_worker->moveToThread(&m_thread);
    connect(&m_thread, &QThread::finished, m_worker, &QObject::deleteLater);
    connect(this, &Dialog::commandRequested, m_worker, &UdpWorker::execute);
    connect(m_worker, &UdpWorker::finished, this, &Dialog::onWorkerFinished);
    m_thread.start();

    // --- Servo ---
    connect(ui->sliderAngle, &QSlider::valueChanged, this, &Dialog::onAngleChanged);
    connect(ui->spinBoxAngle, qOverload<int>(&QSpinBox::valueChanged), this, &Dialog::onAngleChanged);
    connect(&m_liveTimer, &QTimer::timeout, this, &Dialog::onLiveTimer);
    connect(ui->pushButtonSendAngle, &QPushButton::clicked, this, &Dialog::onSendAngleClicked);
    connect(ui->pushButtonAngle0, &QPushButton::clicked, this, [this] {
        setAngleWidgets(0);
        sendAngle(0, false);
    });
    connect(ui->pushButtonAngle90, &QPushButton::clicked, this, [this] {
        setAngleWidgets(90);
        sendAngle(90, false);
    });
    connect(ui->pushButtonAngle180, &QPushButton::clicked, this, [this] {
        setAngleWidgets(180);
        sendAngle(180, false);
    });

    // --- Capteur ---
    connect(ui->pushButtonMeasure, &QPushButton::clicked, this, &Dialog::onMeasureClicked);
    connect(ui->checkBoxContinuous, &QCheckBox::toggled, this, &Dialog::onContinuousToggled);
    connect(&m_pollTimer, &QTimer::timeout, this, &Dialog::onPollTimer);
    connect(ui->spinBoxPeriod, qOverload<int>(&QSpinBox::valueChanged), this, [this](int ms) {
        m_pollTimer.setInterval(ms);
    });

    // --- Balayage SCAN / radar / console ---
    connect(ui->pushButtonScan, &QPushButton::clicked, this, &Dialog::onScanClicked);
    connect(ui->pushButtonClearRadar, &QPushButton::clicked, this, [this] {
        ui->radarWidget->clearPoints();
        ui->tableScan->setRowCount(0);
    });
    connect(ui->spinBoxRange, qOverload<int>(&QSpinBox::valueChanged), this, [this](int cm) {
        ui->radarWidget->setMaxRange(cm);
    });
    connect(ui->lineEditCommand, &QLineEdit::returnPressed, this, &Dialog::onSendRaw);
    connect(ui->pushButtonSendRaw, &QPushButton::clicked, this, &Dialog::onSendRaw);
    connect(ui->pushButtonCancel, &QPushButton::clicked, this, &Dialog::onCancelClicked);

    setBusy(false);
    showStatus(QStringLiteral("Prêt."), false);
    log(QStringLiteral("Prêt. Saisissez l'adresse du routeur et le port, puis envoyez une commande."));
}

Dialog::~Dialog()
{
    // Fermeture propre : on interrompt la requête en cours, on arrête le thread,
    // puis le worker (détruit dans son thread) ferme son socket.
    m_pollTimer.stop();
    m_liveTimer.stop();
    m_worker->shutdown();
    m_thread.quit();
    m_thread.wait();
    delete ui;
}

// ===========================================================================
//  Envoi d'une commande (jamais bloquant : le travail se fait dans le thread réseau)
// ===========================================================================

int Dialog::scanTimeoutMs() const
{
    return ui->spinBoxScanTimeout->value() * 1000;
}

bool Dialog::submit(Kind kind, const QString &command, int timeoutMs, bool quiet)
{
    if (m_pendingId != 0) {
        if (!quiet)
            showStatus(QStringLiteral("Une requête est déjà en cours : patientez ou cliquez sur Annuler."), true);
        return false;
    }

    const QString ip = ui->lineEditIp->text().trimmed();
    const quint16 port = static_cast<quint16>(ui->spinBoxPort->value());

    m_pendingId = m_nextId++;
    m_pendingKind = kind;
    m_pendingQuiet = quiet;
    m_pendingAngle = ui->sliderAngle->value();

    if (!quiet) {
        setBusy(true);
        showStatus(QStringLiteral("En attente de la réponse du serveur…"), false);
        log(QStringLiteral("TX  %1:%2  %3").arg(ip).arg(port).arg(command));
    }

    emit commandRequested(m_pendingId, ip, port, command, timeoutMs, ui->spinBoxRetries->value());
    return true;
}

bool Dialog::sendAngle(int angle, bool quiet)
{
    return submit(Kind::Angle, QStringLiteral("ANGLE %1").arg(angle),
                  ui->spinBoxTimeout->value(), quiet);
}

void Dialog::onCancelClicked()
{
    if (m_pendingId != 0)
        m_worker->cancel();
}

// ===========================================================================
//  Résultat d'une requête (reçu depuis le thread réseau)
// ===========================================================================

void Dialog::onWorkerFinished(int id, int status, const QString &reply,
                              const QString &error, int attempts)
{
    if (id != m_pendingId)
        return;

    const Kind kind = m_pendingKind;
    const bool quiet = m_pendingQuiet;
    const int angle = m_pendingAngle;
    m_pendingId = 0;
    setBusy(false);

    if (status == UDP_ERR_CANCELLED) {
        showStatus(QStringLiteral("Requête annulée."), false);
        log(QStringLiteral("Requête annulée."));
    } else if (status != UDP_OK) {
        showError(error);
        if (kind == Kind::Dist)
            ui->labelDistance->setText(QStringLiteral("--- cm"));
        // Mesure continue : on s'arrête au premier échec plutôt que d'enchaîner les erreurs
        if (quiet && ui->checkBoxContinuous->isChecked())
            ui->checkBoxContinuous->setChecked(false);
    } else {
        if (!quiet) {
            const QString shown = reply.trimmed();
            if (shown.contains(QLatin1Char('\n')))
                log(QStringLiteral("RX  %1 lignes (%2 octets)")
                        .arg(shown.count(QLatin1Char('\n')) + 1).arg(reply.size()));
            else
                log(QStringLiteral("RX  %1").arg(shown));
        }
        if (attempts > 1)
            log(QStringLiteral("Réponse obtenue au bout de %1 essais (datagramme perdu ?)").arg(attempts));

        switch (kind) {
        case Kind::Angle: handleAngleReply(reply, angle); break;
        case Kind::Dist:  handleDistReply(reply, angle);  break;
        case Kind::Scan:  handleScanReply(reply);         break;
        case Kind::Raw:   handleRawReply(reply);          break;
        }
    }

    if (m_liveDirty) {          // le slider a bougé pendant la requête : on envoie la dernière valeur
        m_liveDirty = false;
        onLiveTimer();
    }
}

void Dialog::handleAngleReply(const QString &reply, int angle)
{
    const QString r = reply.simplified();
    if (r == QLatin1String("OK"))
        showStatus(QStringLiteral("Servo orienté à %1°.").arg(angle), false);
    else if (r.startsWith(QLatin1String("ERR")))
        showError(QStringLiteral("Le serveur refuse la commande : %1").arg(r));
    else
        showError(QStringLiteral("Réponse inattendue : « %1 »").arg(r));
}

void Dialog::handleDistReply(const QString &reply, int angle)
{
    const QString r = reply.simplified();
    const QStringList t = r.split(QLatin1Char(' '));

    if (t.value(0) == QLatin1String("DIST")) {
        if (t.value(1) == QLatin1String("TIMEOUT")) {
            ui->labelDistance->setText(QStringLiteral("aucun écho"));
            ui->radarWidget->addPoint(angle, -1.0);
            showStatus(QStringLiteral("Aucun écho à %1°.").arg(angle), false);
            return;
        }
        bool ok = false;
        const double cm = t.value(1).toDouble(&ok);
        if (ok) {
            ui->labelDistance->setText(QStringLiteral("%1 cm").arg(cm, 0, 'f', 1));
            ui->radarWidget->addPoint(angle, cm);
            showStatus(QStringLiteral("Distance mesurée à %1° : %2 cm.").arg(angle).arg(cm, 0, 'f', 1), false);
            return;
        }
    } else if (t.value(0) == QLatin1String("ERR")) {
        showError(QStringLiteral("Le serveur refuse la commande : %1").arg(r));
        return;
    }
    showError(QStringLiteral("Réponse inattendue : « %1 »").arg(r));
}

void Dialog::handleScanReply(const QString &reply)
{
    ui->tableScan->setRowCount(0);
    ui->radarWidget->clearPoints();

    bool sawEnd = false;
    int count = 0;
    int lastAngle = -1;

    const QStringList lines = reply.split(QLatin1Char('\n'));
    for (const QString &raw : lines) {
        const QString line = raw.simplified();
        if (line.isEmpty())
            continue;
        if (line == QLatin1String("END")) {
            sawEnd = true;
            break;
        }
        if (line.startsWith(QLatin1String("ERR"))) {
            showError(QStringLiteral("Le serveur refuse la commande : %1").arg(line));
            return;
        }

        const QStringList t = line.split(QLatin1Char(' '));
        bool okAngle = false;
        const int a = t.value(0).toInt(&okAngle);
        if (!okAngle || t.size() < 2) {
            log(QStringLiteral("Ligne SCAN ignorée : « %1 »").arg(line));
            continue;
        }
        bool okDist = false;
        const double cm = t.value(1).toDouble(&okDist);   // "TIMEOUT" -> pas d'écho

        const int row = ui->tableScan->rowCount();
        ui->tableScan->insertRow(row);
        auto *itemAngle = new QTableWidgetItem(QString::number(a));
        auto *itemDist = new QTableWidgetItem(okDist ? QString::number(cm, 'f', 1)
                                                     : QStringLiteral("aucun écho"));
        itemAngle->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        itemDist->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        ui->tableScan->setItem(row, 0, itemAngle);
        ui->tableScan->setItem(row, 1, itemDist);

        ui->radarWidget->addPoint(a, okDist ? cm : -1.0);
        lastAngle = a;
        ++count;
    }

    if (lastAngle >= 0)
        setAngleWidgets(lastAngle);   // le servo reste à la dernière position du balayage

    if (sawEnd)
        showStatus(QStringLiteral("Balayage terminé : %1 mesures.").arg(count), false);
    else
        showError(QStringLiteral("Réponse SCAN incomplète (ligne END absente) : %1 mesures lues. "
                                 "Le datagramme a peut-être été tronqué : augmentez le pas.").arg(count));
}

void Dialog::handleRawReply(const QString &reply)
{
    const QString r = reply.simplified();
    if (r.startsWith(QLatin1String("ERR")))
        showError(QStringLiteral("Le serveur a répondu : %1").arg(r));
    else
        showStatus(QStringLiteral("Réponse : %1").arg(r.left(120)), false);
}

// ===========================================================================
//  Servo
// ===========================================================================

void Dialog::setAngleWidgets(int angle)
{
    {
        const QSignalBlocker b1(ui->sliderAngle);
        const QSignalBlocker b2(ui->spinBoxAngle);
        ui->sliderAngle->setValue(angle);
        ui->spinBoxAngle->setValue(angle);
    }
    ui->radarWidget->setCurrentAngle(angle);
}

void Dialog::onAngleChanged(int angle)
{
    setAngleWidgets(angle);

    if (ui->checkBoxLive->isChecked() && !m_liveTimer.isActive())
        m_liveTimer.start();   // envoie la valeur la plus récente dans 40 ms
}

void Dialog::onLiveTimer()
{
    if (m_pendingId != 0) {    // requête en cours : on renverra la dernière valeur à la fin
        m_liveDirty = true;
        return;
    }
    sendAngle(ui->sliderAngle->value(), true);
}

void Dialog::onSendAngleClicked()
{
    sendAngle(ui->sliderAngle->value(), false);
}

// ===========================================================================
//  Capteur
// ===========================================================================

void Dialog::onMeasureClicked()
{
    submit(Kind::Dist, QStringLiteral("DIST"), ui->spinBoxTimeout->value(), false);
}

void Dialog::onContinuousToggled(bool on)
{
    if (on) {
        onPollTimer();
        m_pollTimer.start();
    } else {
        m_pollTimer.stop();
    }
}

void Dialog::onPollTimer()
{
    if (m_pendingId != 0)
        return;   // la requête précédente n'est pas terminée
    submit(Kind::Dist, QStringLiteral("DIST"), ui->spinBoxTimeout->value(), true);
}

// ===========================================================================
//  Balayage (SCAN) et console
// ===========================================================================

void Dialog::onScanClicked()
{
    const int begin = ui->spinBoxMin->value();
    const int end = ui->spinBoxMax->value();
    const int step = ui->spinBoxStep->value();

    if (begin > end) {
        showError(QStringLiteral("Balayage : l'angle de début doit être inférieur ou égal à l'angle de fin."));
        return;
    }
    const int points = (end - begin) / step + 1;
    if (points > kMaxScanPoints) {
        showError(QStringLiteral("Balayage : %1 mesures demandées. La réponse doit tenir dans un seul "
                                 "datagramme UDP : limitez-vous à %2 mesures (augmentez le pas).")
                      .arg(points).arg(kMaxScanPoints));
        return;
    }

    ui->checkBoxContinuous->setChecked(false);   // arrête la mesure continue
    m_liveTimer.stop();
    m_liveDirty = false;

    submit(Kind::Scan, QStringLiteral("SCAN %1 %2 %3").arg(begin).arg(end).arg(step),
           scanTimeoutMs(), false);
}

void Dialog::onSendRaw()
{
    const QString text = ui->lineEditCommand->text().simplified();
    if (text.isEmpty())
        return;

    // Les commandes connues sont traitées comme depuis les boutons (tableau, radar...)
    const QString word = text.section(QLatin1Char(' '), 0, 0).toUpper();
    Kind kind = Kind::Raw;
    int timeout = ui->spinBoxTimeout->value();
    if (word == QLatin1String("SCAN")) {
        kind = Kind::Scan;
        timeout = scanTimeoutMs();
    } else if (word == QLatin1String("DIST")) {
        kind = Kind::Dist;
    }

    if (submit(kind, text, timeout, false))
        ui->lineEditCommand->clear();
}

// ===========================================================================
//  Affichage
// ===========================================================================

void Dialog::setBusy(bool busy)
{
    ui->pushButtonMeasure->setEnabled(!busy);
    ui->pushButtonSendAngle->setEnabled(!busy);
    ui->pushButtonAngle0->setEnabled(!busy);
    ui->pushButtonAngle90->setEnabled(!busy);
    ui->pushButtonAngle180->setEnabled(!busy);
    ui->pushButtonScan->setEnabled(!busy);
    ui->pushButtonSendRaw->setEnabled(!busy);
    ui->pushButtonCancel->setEnabled(busy);
}

void Dialog::showStatus(const QString &text, bool isError)
{
    ui->labelStatus->setText(text);
    ui->labelStatus->setStyleSheet(isError ? QStringLiteral("color: #d9534f; font-weight: bold;")
                                           : QString());
}

void Dialog::showError(const QString &text)
{
    showStatus(text, true);
    log(QStringLiteral("ERREUR  %1").arg(text));
}

void Dialog::log(const QString &line)
{
    ui->plainTextEditLog->appendPlainText(
        QTime::currentTime().toString(QStringLiteral("HH:mm:ss.zzz")) + QStringLiteral("  ") + line);
}
