#include "udpnet.h"

#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
  #include <winsock2.h>
  #include <ws2tcpip.h>
  typedef SOCKET sock_t;
  #define SOCK_INVALID      INVALID_SOCKET
  #define sock_close        closesocket
  #define sock_errno()      WSAGetLastError()
  #define ERR_CONNRESET     WSAECONNRESET
  #define ERR_MSGSIZE       WSAEMSGSIZE
  #define IS_INTERRUPTED(e) 0
#else
  #include <arpa/inet.h>
  #include <netinet/in.h>
  #include <sys/select.h>
  #include <sys/socket.h>
  #include <unistd.h>
  typedef int sock_t;
  #define SOCK_INVALID      (-1)
  #define sock_close        close
  #define sock_errno()      errno
  #define ERR_CONNRESET     ECONNREFUSED
  #define ERR_MSGSIZE       EMSGSIZE
  #define IS_INTERRUPTED(e) ((e) == EINTR)
#endif

#define SLICE_MS 100   /* l'attente est découpée en tranches pour pouvoir réagir à 'cancel' */

struct UdpClient {
    sock_t sock;
    struct sockaddr_in dest;
};

/* ------------------------------------------------------------------------- */

static void set_err(char *err, size_t size, const char *fmt, ...)
{
    va_list ap;
    if (!err || size == 0)
        return;
    va_start(ap, fmt);
    vsnprintf(err, size, fmt, ap);
    va_end(ap);
}

static void set_sock_err(char *err, size_t size, const char *what)
{
    const int e = sock_errno();
#ifdef _WIN32
    set_err(err, size, "%s (erreur Winsock %d)", what, e);
#else
    set_err(err, size, "%s : %s", what, strerror(e));
#endif
}

/* Vide les datagrammes déjà reçus (réponses tardives d'une requête précédente). */
static void drain(UdpClient *c)
{
    char buf[2048];
    for (;;) {
        fd_set rfds;
        struct timeval tv;
        tv.tv_sec = 0;
        tv.tv_usec = 0;
        FD_ZERO(&rfds);
        FD_SET(c->sock, &rfds);
        if (select((int)c->sock + 1, &rfds, NULL, NULL, &tv) <= 0)
            break;
        if (recvfrom(c->sock, buf, (int)sizeof buf, 0, NULL, NULL) < 0)
            break;
    }
}

/* Attend un datagramme pendant timeout_ms. UDP_OK, UDP_ERR_TIMEOUT (silencieux) ou erreur. */
static int wait_reply(UdpClient *c, char *reply, size_t replysize, int timeout_ms,
                      const volatile int *cancel, char *err, size_t errsize)
{
    int waited = 0;

    while (waited < timeout_ms) {
        int slice = timeout_ms - waited;
        int n, r;
        fd_set rfds;
        struct timeval tv;

        if (cancel && *cancel) {
            set_err(err, errsize, "Opération annulée");
            return UDP_ERR_CANCELLED;
        }
        if (slice > SLICE_MS)
            slice = SLICE_MS;

        FD_ZERO(&rfds);
        FD_SET(c->sock, &rfds);
        tv.tv_sec = slice / 1000;
        tv.tv_usec = (slice % 1000) * 1000;

        n = select((int)c->sock + 1, &rfds, NULL, NULL, &tv);
        if (n < 0) {
            if (IS_INTERRUPTED(sock_errno()))
                continue;
            set_sock_err(err, errsize, "Erreur d'attente de réponse");
            return UDP_ERR_RECV;
        }
        if (n == 0) {              /* rien reçu pendant cette tranche */
            waited += slice;
            continue;
        }

        r = (int)recvfrom(c->sock, reply, (int)(replysize - 1), 0, NULL, NULL);
        if (r < 0) {
            const int e = sock_errno();
            if (e == ERR_CONNRESET) {
                set_err(err, errsize, "Serveur injoignable (port fermé, pare-feu ou routeur : message ICMP reçu)");
                return UDP_ERR_UNREACHABLE;
            }
            if (e == ERR_MSGSIZE) {
                set_err(err, errsize, "Réponse trop grande pour le tampon de réception");
                return UDP_ERR_RECV;
            }
            set_sock_err(err, errsize, "Erreur de réception");
            return UDP_ERR_RECV;
        }
        reply[r] = '\0';
        return UDP_OK;
    }
    return UDP_ERR_TIMEOUT;
}

/* ------------------------------------------------------------------------- */

UdpClient *udp_open(const char *ip, unsigned short port, char *err, size_t errsize)
{
    UdpClient *c;
    unsigned long addr;

    if (!ip || port == 0) {
        set_err(err, errsize, "Adresse ou port invalide");
        return NULL;
    }
    addr = inet_addr(ip);
    if (addr == INADDR_NONE) {
        set_err(err, errsize, "Adresse IPv4 invalide : « %s »", ip);
        return NULL;
    }

#ifdef _WIN32
    {
        WSADATA wsa;
        const int r = WSAStartup(MAKEWORD(2, 2), &wsa);
        if (r != 0) {
            set_err(err, errsize, "Initialisation Winsock impossible (code %d)", r);
            return NULL;
        }
    }
#endif

    c = (UdpClient *)calloc(1, sizeof *c);
    if (!c) {
        set_err(err, errsize, "Mémoire insuffisante");
#ifdef _WIN32
        WSACleanup();
#endif
        return NULL;
    }

    c->dest.sin_family = AF_INET;
    c->dest.sin_port = htons(port);
    c->dest.sin_addr.s_addr = addr;

    c->sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (c->sock == SOCK_INVALID) {
        set_sock_err(err, errsize, "Création du socket impossible");
        free(c);
#ifdef _WIN32
        WSACleanup();
#endif
        return NULL;
    }
    return c;
}

int udp_request(UdpClient *c, const char *cmd,
                char *reply, size_t replysize,
                int timeout_ms, int tries,
                const volatile int *cancel, int *attempts,
                char *err, size_t errsize)
{
    char out[256];
    size_t len;
    int attempt, rc;

    if (attempts)
        *attempts = 0;
    if (!c || !cmd || !reply || replysize < 2) {
        set_err(err, errsize, "Paramètre invalide");
        return UDP_ERR_ARG;
    }
    if (tries < 1)
        tries = 1;
    if (timeout_ms < 1)
        timeout_ms = 1;

    /* Message ASCII terminé par un seul '\n' */
    len = strlen(cmd);
    while (len > 0 && (cmd[len - 1] == '\n' || cmd[len - 1] == '\r'))
        len--;
    if (len == 0 || len + 2 > sizeof out) {
        set_err(err, errsize, "Commande vide ou trop longue");
        return UDP_ERR_ARG;
    }
    memcpy(out, cmd, len);
    out[len++] = '\n';

    drain(c);

    for (attempt = 1; attempt <= tries; ++attempt) {
        if (attempts)
            *attempts = attempt;

        if (sendto(c->sock, out, (int)len, 0,
                   (struct sockaddr *)&c->dest, (int)sizeof c->dest) < 0) {
            set_sock_err(err, errsize, "Envoi impossible");
            return UDP_ERR_SEND;
        }

        rc = wait_reply(c, reply, replysize, timeout_ms, cancel, err, errsize);
        if (rc != UDP_ERR_TIMEOUT)
            return rc;          /* réponse reçue, annulation ou erreur : on s'arrête */
        /* timeout : datagramme perdu ? on renvoie la commande */
    }

    set_err(err, errsize, "Pas de réponse du serveur (%d essai(s) de %d ms)", tries, timeout_ms);
    return UDP_ERR_TIMEOUT;
}

void udp_close(UdpClient *c)
{
    if (!c)
        return;
    sock_close(c->sock);
    free(c);
#ifdef _WIN32
    WSACleanup();
#endif
}
