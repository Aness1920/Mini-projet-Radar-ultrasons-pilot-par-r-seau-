#ifndef RADARWIDGET_H
#define RADARWIDGET_H

#include <QMap>
#include <QWidget>

/*
 * Affichage "radar" (demi-disque 0..180°) des mesures du capteur à ultrasons.
 * Convention : 0° à droite, 90° en haut, 180° à gauche.
 * Une seule mesure est conservée par angle (la plus récente).
 */
class RadarWidget : public QWidget
{
    Q_OBJECT

public:
    explicit RadarWidget(QWidget *parent = nullptr);

    void setMaxRange(double cm);          // portée affichée (rayon extérieur)
    void setCurrentAngle(int angleDeg);   // position courante du servo
    void addPoint(int angleDeg, double distanceCm);
    void clearPoints();

    QSize minimumSizeHint() const override { return QSize(320, 200); }
    QSize sizeHint() const override { return QSize(560, 340); }

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QMap<int, double> m_echoes;   // angle -> distance (cm)
    int m_angle = 90;
    double m_maxRange = 200.0;
};

#endif // RADARWIDGET_H
