#include "udpworker.h"

#include <QByteArray>

UdpWorker::UdpWorker(QObject *parent)
    : QObject(parent)
{
}

UdpWorker::~UdpWorker()
{
    closeClient();   // fermeture propre du socket
}

void UdpWorker::cancel()
{
    m_cancel = 1;
}

void UdpWorker::shutdown()
{
    m_shutdown = 1;
    m_cancel = 1;
}

void UdpWorker::closeClient()
{
    if (m_client) {
        udp_close(m_client);
        m_client = nullptr;
    }
}

void UdpWorker::execute(int id, const QString &ip, quint16 port, const QString &command,
                        int timeoutMs, int tries)
{
    if (m_shutdown)
        return;
    m_cancel = 0;

    char err[256] = {0};

    // (Ré)ouvre le socket si la destination saisie dans l'interface a changé
    if (!m_client || ip != m_ip || port != m_port) {
        closeClient();
        const QByteArray ipBytes = ip.toLatin1();
        m_client = udp_open(ipBytes.constData(), port, err, sizeof err);
        if (!m_client) {
            emit finished(id, UDP_ERR_INIT, QString(), QString::fromUtf8(err), 0);
            return;
        }
        m_ip = ip;
        m_port = port;
    }

    const QByteArray cmd = command.toLatin1();   // protocole ASCII
    QByteArray reply(16384, '\0');               // la réponse à SCAN tient dans un datagramme
    int attempts = 0;

    const int rc = udp_request(m_client, cmd.constData(), reply.data(), reply.size(),
                               timeoutMs, tries, &m_cancel, &attempts, err, sizeof err);

    emit finished(id, rc,
                  rc == UDP_OK ? QString::fromLatin1(reply.constData()) : QString(),
                  QString::fromUtf8(err), attempts);
}
