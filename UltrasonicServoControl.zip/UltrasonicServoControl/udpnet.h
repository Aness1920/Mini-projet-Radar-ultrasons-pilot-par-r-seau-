#ifndef UDPNET_H
#define UDPNET_H

/*
 * Module réseau UDP (C pur, Winsock sous Windows / sockets BSD sous Linux).
 *
 * Principe : un client UDP "requête / réponse".
 *   - udp_open()    crée le socket pour une destination (adresse IPv4 + port)
 *   - udp_request() envoie une commande (terminée par '\n') et attend la réponse,
 *                   avec délai d'attente et nouveaux essais (UDP peut perdre des datagrammes)
 *   - udp_close()   ferme le socket
 *
 * Les fonctions sont BLOQUANTES : à appeler depuis un thread de travail pour
 * ne pas figer une interface graphique.
 */

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct UdpClient UdpClient;   /* type opaque */

/* Codes retour de udp_request() */
enum {
    UDP_OK              =  0,
    UDP_ERR_ARG         = -1,   /* paramètre invalide (adresse, port, tampon, commande trop longue) */
    UDP_ERR_INIT        = -2,   /* initialisation Winsock / création du socket impossible */
    UDP_ERR_SEND        = -3,   /* échec de l'envoi */
    UDP_ERR_RECV        = -4,   /* échec de la réception (ou réponse trop grande pour le tampon) */
    UDP_ERR_TIMEOUT     = -5,   /* aucune réponse après tous les essais */
    UDP_ERR_CANCELLED   = -6,   /* annulé par l'appelant (drapeau cancel) */
    UDP_ERR_UNREACHABLE = -7    /* hôte / port inaccessible (message ICMP reçu) */
};

/* Ouvre un client vers ip:port. Retourne NULL en cas d'erreur (message dans err). */
UdpClient *udp_open(const char *ip, unsigned short port, char *err, size_t errsize);

/*
 * Envoie 'cmd' (le '\n' final est ajouté si absent) et attend la réponse.
 *   reply/replysize : tampon de réponse (terminé par '\0')
 *   timeout_ms      : délai d'attente de la réponse, PAR ESSAI
 *   tries           : nombre total d'essais (>= 1) ; la commande est renvoyée après chaque timeout
 *   cancel          : si non NULL, l'attente s'interrompt (UDP_ERR_CANCELLED) quand *cancel != 0
 *   attempts        : (sortie, peut être NULL) nombre d'essais effectués
 *   err/errsize     : (sortie) message d'erreur lisible
 * Retourne UDP_OK ou un code d'erreur négatif.
 */
int udp_request(UdpClient *c, const char *cmd,
                char *reply, size_t replysize,
                int timeout_ms, int tries,
                const volatile int *cancel, int *attempts,
                char *err, size_t errsize);

/* Ferme le socket et libère les ressources (NULL accepté). */
void udp_close(UdpClient *c);

#ifdef __cplusplus
}
#endif

#endif /* UDPNET_H */
