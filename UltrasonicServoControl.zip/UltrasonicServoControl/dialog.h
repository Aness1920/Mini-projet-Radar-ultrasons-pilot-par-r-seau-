#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QThread>
#include <QTimer>

QT_BEGIN_NAMESPACE
namespace Ui { class Dialog; }
QT_END_NAMESPACE

class UdpWorker;

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog() override;

signals:
    // Demande envoyée au thread réseau (relié à UdpWorker::execute)
    void commandRequested(int id, const QString &ip, quint16 port, const QString &command,
                          int timeoutMs, int tries);

private slots:
    void onAngleChanged(int angle);
    void onLiveTimer();
    void onSendAngleClicked();
    void onMeasureClicked();
    void onContinuousToggled(bool on);
    void onPollTimer();
    void onScanClicked();
    void onSendRaw();
    void onCancelClicked();
    void onWorkerFinished(int id, int status, const QString &reply,
                          const QString &error, int attempts);

private:
    enum class Kind { Angle, Dist, Scan, Raw };

    // Envoi d'une commande au thread réseau (une seule requête à la fois)
    bool submit(Kind kind, const QString &command, int timeoutMs, bool quiet);
    bool sendAngle(int angle, bool quiet);
    int  scanTimeoutMs() const;

    // Traitement des réponses
    void handleAngleReply(const QString &reply, int angle);
    void handleDistReply(const QString &reply, int angle);
    void handleScanReply(const QString &reply);
    void handleRawReply(const QString &reply);

    // Interface
    void setAngleWidgets(int angle);
    void setBusy(bool busy);
    void showStatus(const QString &text, bool isError);
    void showError(const QString &text);
    void log(const QString &line);

    Ui::Dialog *ui;

    QThread    m_thread;
    UdpWorker *m_worker = nullptr;

    QTimer m_liveTimer;   // limite le débit d'envoi pendant le glissement du slider
    QTimer m_pollTimer;   // mesure continue

    int  m_nextId = 1;
    int  m_pendingId = 0;            // 0 = aucune requête en cours
    Kind m_pendingKind = Kind::Raw;
    bool m_pendingQuiet = false;
    int  m_pendingAngle = 0;
    bool m_liveDirty = false;        // le slider a bougé pendant une requête
};

#endif // DIALOG_H
