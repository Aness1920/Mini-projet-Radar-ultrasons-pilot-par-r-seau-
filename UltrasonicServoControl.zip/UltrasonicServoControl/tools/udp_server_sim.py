#!/usr/bin/env python3
"""Simulateur de la carte radar ultrasons (protocole du mini-projet).

  ANGLE <a>               -> "OK"  ou  "ERR <motif>"
  DIST                    -> "DIST <cm>"  ou  "DIST TIMEOUT" (aucun écho)
  SCAN <début> <fin> <pas>-> une ligne "<angle> <cm>" par mesure, puis "END" (un seul datagramme)

Messages ASCII terminés par '\\n'. La réponse revient vers l'adresse/port de l'expéditeur.

Usage : python3 udp_server_sim.py [port] [taux_de_perte]
  taux_de_perte (0..1) : probabilité d'ignorer un datagramme reçu, pour tester les nouveaux essais.
"""
import math
import random
import socket
import sys

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
LOSS = float(sys.argv[2]) if len(sys.argv) > 2 else 0.0
MAX_SCAN = 100
angle = 90


def measure(a):
    """Distance fictive en cm ; aucun écho entre 120° et 130°."""
    if 120 <= a <= 130:
        return None
    return 90 + 50 * math.sin(math.radians(a * 2)) + random.uniform(-1.5, 1.5)


def handle(msg):
    global angle
    parts = msg.split()
    if not parts:
        return "ERR commande vide\n"
    cmd = parts[0].upper()

    if cmd == "ANGLE" and len(parts) == 2:
        try:
            a = int(parts[1])
        except ValueError:
            return "ERR angle invalide\n"
        if not 0 <= a <= 180:
            return "ERR angle hors plage\n"
        angle = a
        return "OK\n"

    if cmd == "DIST" and len(parts) == 1:
        d = measure(angle)
        return "DIST TIMEOUT\n" if d is None else f"DIST {d:.1f}\n"

    if cmd == "SCAN" and len(parts) == 4:
        try:
            start, end, step = (int(p) for p in parts[1:])
        except ValueError:
            return "ERR parametres invalides\n"
        if not (0 <= start <= end <= 180) or step < 1:
            return "ERR parametres hors plage\n"
        if (end - start) // step + 1 > MAX_SCAN:
            return "ERR trop de mesures\n"
        lines = []
        for a in range(start, end + 1, step):
            d = measure(a)
            lines.append(f"{a} {d:.1f}" if d is not None else f"{a} TIMEOUT")
            angle = a
        return "\n".join(lines) + "\nEND\n"

    return "ERR commande inconnue\n"


sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("0.0.0.0", PORT))
print(f"Simulateur en écoute sur UDP/{PORT} (perte simulée : {LOSS:.0%})", flush=True)

while True:
    data, addr = sock.recvfrom(2048)
    msg = data.decode("ascii", errors="replace")
    if random.random() < LOSS:
        print(f"{addr[0]}:{addr[1]}  <- {msg.strip()!r}   (ignoré : perte simulée)", flush=True)
        continue
    reply = handle(msg)
    sock.sendto(reply.encode("ascii"), addr)
    print(f"{addr[0]}:{addr[1]}  <- {msg.strip()!r}  -> {reply.splitlines()[0]!r}", flush=True)
