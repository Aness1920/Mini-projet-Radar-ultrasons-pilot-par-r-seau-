/*
----------------------------------------------------------------------------
Projet : Pilotage distant via serveur UDP d'un capteur ultrasons orientable
Programme : Pilotage distant sur requete UDP via notre IHM
----------------------------------------------------------------------------
Auteur : Lucas VINCENTI, BUT3 ESE FA
Binome : Anes BENHAMED, BUT3 ESE FA
----------------------------------------------------------------------------
Objectifs du programme :
    - Interface Minimaliste a des fins de démo
    - envoi de requete UDP sur notre serveur distant (acces depuis le wan du
      routeur cisco sur @192.168.184.160 et port 8000 (single port forwarding
      configuré sur le routeur
----------------------------------------------------------------------------
On va EZ la soutenance Anes !
*/

#include <QApplication>
#include <QHBoxLayout>
#include <QHostAddress>
#include <QLabel>
#include <QLineEdit>
#include <QNetworkDatagram>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QSpinBox>
#include <QUdpSocket>
#include <QVBoxLayout>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    // --- Widgets ---
    auto *ip       = new QLineEdit("192.168.184.160");
    auto *port     = new QSpinBox;
    auto *terminal = new QPlainTextEdit;
    auto *command  = new QLineEdit;
    auto *send     = new QPushButton("Envoyer");

    port->setRange(1, 65535);
    port->setValue(8000);
    terminal->setReadOnly(true);
    command->setPlaceholderText("Commande (ex. DIST)");

    // --- Disposition ---
    auto *top = new QHBoxLayout;
    top->addWidget(new QLabel("Adresse IP :"));
    top->addWidget(ip, 1);
    top->addWidget(new QLabel("Port :"));
    top->addWidget(port);

    auto *bottom = new QHBoxLayout;
    bottom->addWidget(command, 1);
    bottom->addWidget(send);

    QWidget window;
    window.setWindowTitle("Client UDP");
    window.resize(480, 320);
    auto *layout = new QVBoxLayout(&window);
    layout->addLayout(top);
    layout->addWidget(terminal, 1);
    layout->addLayout(bottom);

    // --- Réseau ---
    QUdpSocket socket;

    auto sendCommand = [&]() {
        //Fonction d'envoi : Recupere le texte de notre terminal et l'envoi
        const QString text = command->text().trimmed();
        if (text.isEmpty())
            return;

        QHostAddress address;
        if (!address.setAddress(ip->text().trimmed())) {
            terminal->appendPlainText("Adresse IP invalide");
            return;
        }

        // message ASCII terminé par un saut de ligne
        if (socket.writeDatagram(text.toLatin1() + '\n', address, quint16(port->value())) < 0)
            terminal->appendPlainText("Erreur d'envoi : " + socket.errorString());
        else
            terminal->appendPlainText("> " + text);
        command->clear();
    };

    QObject::connect(send, &QPushButton::clicked, sendCommand);
    QObject::connect(command, &QLineEdit::returnPressed, sendCommand);

    QObject::connect(&socket, &QUdpSocket::readyRead, [&]() {
        while (socket.hasPendingDatagrams())
            terminal->appendPlainText("< " + QString::fromLatin1(socket.receiveDatagram().data()).trimmed());
    });

    window.show();
    return app.exec();
}
