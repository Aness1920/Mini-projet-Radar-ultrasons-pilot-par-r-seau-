QT       += core gui network
greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

TARGET = UdpMini
TEMPLATE = app

SOURCES += main.cpp
