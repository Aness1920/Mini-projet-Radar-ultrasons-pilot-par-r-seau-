#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QTimer>
#include <QUdpSocket>

class QLineEdit;
class QPlainTextEdit;
class QPushButton;
class QSpinBox;

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);

private slots:
    void toggleConnection();   // bouton Connecter / Déconnecter
    void sendCommand();        // bouton Envoyer (ou touche Entrée)
    void readReply();          // une réponse est arrivée
    void onError();            // erreur réseau
    void updateUi();           // active / désactive les widgets selon l'état

private:
    void log(const QString &line);

    QLineEdit      *m_ip;
    QSpinBox       *m_port;
    QPushButton    *m_connectButton;
    QLineEdit      *m_command;
    QPushButton    *m_sendButton;
    QPlainTextEdit *m_log;

    QUdpSocket m_socket;
    QTimer     m_timeout;      // signale l'absence de réponse
};

#endif // DIALOG_H
