#include "dialog.h"

#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QSpinBox>
#include <QVBoxLayout>

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
{
    setWindowTitle(QStringLiteral("Client UDP"));
    resize(520, 380);

    // --- Ligne 1 : adresse, port, bouton de connexion ---
    m_ip = new QLineEdit(QStringLiteral("192.168.184.160"));
    m_port = new QSpinBox;
    m_port->setRange(1, 65535);
    m_port->setValue(8000);
    m_connectButton = new QPushButton;

    auto *line1 = new QHBoxLayout;
    line1->addWidget(new QLabel(QStringLiteral("Adresse :")));
    line1->addWidget(m_ip, 1);
    line1->addWidget(new QLabel(QStringLiteral("Port :")));
    line1->addWidget(m_port);
    line1->addWidget(m_connectButton);

    // --- Ligne 2 : commande à envoyer ---
    m_command = new QLineEdit;
    m_command->setPlaceholderText(QStringLiteral("ANGLE 90   |   DIST   |   SCAN 0 180 10"));
    m_sendButton = new QPushButton(QStringLiteral("Envoyer"));

    auto *line2 = new QHBoxLayout;
    line2->addWidget(m_command, 1);
    line2->addWidget(m_sendButton);

    // --- Journal ---
    m_log = new QPlainTextEdit;
    m_log->setReadOnly(true);

    auto *layout = new QVBoxLayout(this);
    layout->addLayout(line1);
    layout->addLayout(line2);
    layout->addWidget(m_log, 1);

    m_connectButton->setAutoDefault(false);
    m_sendButton->setAutoDefault(false);

    m_timeout.setSingleShot(true);

    // --- Connexions ---
    connect(m_connectButton, &QPushButton::clicked, this, &Dialog::toggleConnection);
    connect(m_sendButton, &QPushButton::clicked, this, &Dialog::sendCommand);
    connect(m_command, &QLineEdit::returnPressed, this, &Dialog::sendCommand);

    connect(&m_socket, &QUdpSocket::readyRead, this, &Dialog::readReply);
    connect(&m_socket, &QUdpSocket::stateChanged, this, &Dialog::updateUi);
    connect(&m_socket, &QUdpSocket::connected, this, [this] {
        log(QStringLiteral("Connecté à %1:%2 (UDP : aucun échange réseau à la connexion)")
                .arg(m_socket.peerName()).arg(m_socket.peerPort()));
    });
    connect(&m_socket, &QUdpSocket::disconnected, this, [this] {
        log(QStringLiteral("Déconnecté."));
    });
#if QT_VERSION >= QT_VERSION_CHECK(5, 15, 0)
    connect(&m_socket, &QUdpSocket::errorOccurred, this, &Dialog::onError);
#else
    connect(&m_socket, QOverload<QAbstractSocket::SocketError>::of(&QUdpSocket::error),
            this, &Dialog::onError);
#endif
    connect(&m_timeout, &QTimer::timeout, this, [this] {
        log(QStringLiteral("Pas de réponse du serveur (1 s)."));
    });

    updateUi();
}

void Dialog::toggleConnection()
{
    if (m_socket.state() == QAbstractSocket::UnconnectedState) {
        m_socket.connectToHost(m_ip->text().trimmed(), static_cast<quint16>(m_port->value()));
    } else {
        m_timeout.stop();
        m_socket.abort();          // ferme le socket
        log(QStringLiteral("Déconnecté."));
    }
}

void Dialog::sendCommand()
{
    const QString cmd = m_command->text().trimmed();
    if (cmd.isEmpty() || m_socket.state() != QAbstractSocket::ConnectedState)
        return;

    // Le protocole : message ASCII terminé par un saut de ligne
    if (m_socket.write(cmd.toLatin1() + '\n') < 0) {
        log(QStringLiteral("Erreur d'envoi : %1").arg(m_socket.errorString()));
        return;
    }
    log(QStringLiteral("TX  %1").arg(cmd));
    m_command->clear();
    m_timeout.start(1000);
}

void Dialog::readReply()
{
    while (m_socket.hasPendingDatagrams()) {
        const QByteArray data = m_socket.receiveDatagram().data();
        m_timeout.stop();
        log(QStringLiteral("RX  %1").arg(QString::fromLatin1(data).trimmed()));
    }
}

void Dialog::onError()
{
    m_timeout.stop();
    log(QStringLiteral("ERREUR : %1").arg(m_socket.errorString()));
}

void Dialog::updateUi()
{
    const bool connected = (m_socket.state() == QAbstractSocket::ConnectedState);
    const bool idle = (m_socket.state() == QAbstractSocket::UnconnectedState);

    m_connectButton->setText(idle ? QStringLiteral("Connecter") : QStringLiteral("Déconnecter"));
    m_ip->setEnabled(idle);
    m_port->setEnabled(idle);
    m_command->setEnabled(connected);
    m_sendButton->setEnabled(connected);
    if (connected)
        m_command->setFocus();
}

void Dialog::log(const QString &line)
{
    m_log->appendPlainText(line);
}
