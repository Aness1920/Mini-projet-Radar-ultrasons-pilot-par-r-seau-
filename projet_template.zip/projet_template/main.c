#include "stm32f7xx.h"                  // Device header

extern void configuration_overclock(void);
extern int Init_GUIThread (void);
extern void Init_Ethernet (void);

float distance_cm(void);
volatile float servo_set_angle(int deg);
int angle_servo = 0;
float distance = 0;

#ifdef _RTE_
#include "RTE_Components.h"             // Component selection
#endif
#ifdef RTE_CMSIS_RTOS2                  // when RTE component CMSIS RTOS2 is used
#include "cmsis_os2.h"                  // ::CMSIS:RTOS2
#endif

/*----------------------------------------------------------------------------
 *      T�che de test (vide) : � compl�ter par les �tudiants
 *---------------------------------------------------------------------------*/
osThreadId_t tid_Test;

static void Thread_Test (void *argument)
{
  (void)argument;
	int pas = 1;

  // Initialisations propres � la t�che (si besoin) ici

  while (1)
  {
    // Votre boucle de test ici (mesure de distance, balayage du servo, etc.)
		//servo_set_angle(90);
		angle_servo = angle_servo + pas;
		if (angle_servo >= 180 ) pas = -1;
		if (angle_servo <= 0	 ) pas = 1;
		servo_set_angle(angle_servo);

    osDelay(300);   // p�riode de la boucle : 100 ms
		distance = distance_cm();
  }
}

static int Init_TestThread (void)
{
  tid_Test = osThreadNew(Thread_Test, NULL, NULL);
  if (tid_Test == NULL) {
    return -1;
  }
  return 0;
}


int main(void)
{
  configuration_overclock(); //pour pouvoir utiliser l'�cran LCD

	/**********************************
	D�but Initialisation p�riph�rique
	**********************************/
	//I
	//Init_Ethernet();         
	
	RCC->AHB1ENR  |= (1<<8); //activer GPIOI
	GPIOI->MODER  |= (1<<4); //PI2 en sortie 
	
	
	RCC->APB1ENR |= (1<<29); //Activer la DAC
	RCC->AHB1ENR |= (1<<0); // activer GPIOA
	GPIOA->MODER |= (3 <<8); //PA4 in analog mode
	DAC->CR |= (1<<0); // activates output channel 1( PA4)
	
	
	RCC->AHB1ENR |= (1<<5); // activer GPIOF
	RCC->APB2ENR |= (1<<17);//activer le timer 10
	GPIOF->MODER |= (2<<12);//PF6 in AF mode
	GPIOF->AFR[0] |= (3<<24);//PF6 in AF3 mode (TIM10_CH1)
	TIM10->CCMR1 |= (6<<4); // configurer le timer 10 en PWM
	TIM10->CCER |= (1<<0); // connect OC1 a TIM10_CH1
	TIM10->PSC = 53;
	TIM10->ARR = 39999;
	TIM10->CCR1 = 3000;
	TIM10->CR1 |= (1<<0);// start counter

	
	RCC->APB2ENR |= (1<<10); // Activer la ADC
	//GPIOF->MODER |= (3 <<12);//PF6 IN analog mode
	GPIOF->MODER |= (3<<20); // poto in alnalog
	RCC->AHB1ENR |=  (1<<4);
	ADC3->SQR3 |= (8<<0);
	ADC3->CR2 |= (1<<0); // conversion adc start


	RCC->AHB1ENR |= (1<<1); // activer GPIOB
	GPIOB->MODER |= (1<<28);// PB14 en sortie (TRIG)
	// PB15 en entree (ECHO) : rien a ecrire, c'est le mode par defaut

	RCC->APB1ENR |= (1<<0); // activer le timer 2
	TIM2->PSC = 107;        // 1 tic = 1 �s (si TIM2 est a 108 MHz)
	TIM2->ARR = 39999; 			// compte jusqu'au maximum
	TIM2->CR1 |= (1<<0);    // start counter




	//Initialiser vos p�riph�riques ici

	/**********************************
	Fin Initialisation p�riph�rique
	**********************************/

	/**********************************
	Utilisation RTOS (Keil RTX5)
	**********************************/
	#ifdef RTE_CMSIS_RTOS2
	  /* Initialize CMSIS-RTOS2 */
	  osKernelInitialize ();

	  /* Create thread functions that start executing */
		Init_Ethernet();
		Init_GUIThread();
		Init_TestThread();   // t�che de test (boucle avec osDelay)

	  /* Start thread execution */
	  osKernelStart();
	#endif

  /* Infinite loop  (ne s'ex�cute pas avec le RTOS!!!)*/
  while (1)
  {
  }
}

volatile float servo_set_angle(int deg){
	float Val;
	
	if (deg < 0) deg = 0;
	if (deg > 180) deg = 180;
	
	Val = 2000 + ((deg *( 4000 - 2000 ))/180);
	TIM10->CCR1 = Val;
}



float distance_cm(void)
{

	TIM2->CNT = 0;
	// impulsion de 10 �s sur TRIG (PB14)
	GPIOB->BSRR |= (1<<14);  // TRIG = 1
	while(TIM2->CNT<10);
	GPIOB->BSRR |= (1<<30);  // TRIG = 0  (14 + 16 = 30)

	// attendre que ECHO (PB15) passe a 1, 30 ms max
	while ((GPIOB->IDR & (1<<15)) == 0)
	{
		if ((TIM2->CNT ) > 30000) return -1; // TIMEOUT
	}

	// mesurer combien de temps ECHO reste a 1

	while ((GPIOB->IDR & (1<<15)) != 0)
	{
		if ((TIM2->CNT ) > 30000) return -1; // TIMEOUT
	}


	// 4) conversion en cm
	return TIM2->CNT / 58.0;
}

