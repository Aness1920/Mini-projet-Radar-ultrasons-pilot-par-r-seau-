/*------------------------------------------------------------------------------
 * MDK Middleware - Component ::Network:Service
 * Copyright (c) 2004-2019 Arm Limited (or its affiliates). All rights reserved.
 *------------------------------------------------------------------------------
 * Name:    UDP_Socket.c
 * Purpose: Serveur UDP du radar : commandes ANGLE, DIST et SCAN
 * Rev.:    V7.0.0
 *----------------------------------------------------------------------------*/
//! [code_UDP_Socket]
#include "rl_net.h"
#include "cmsis_os2.h"                  // pour osDelay
#include "stm32f7xx.h"                  // Device header
#include "AppWizard.h"
#include <stdio.h>
#include <string.h>


#define UDP_PORT     5000               // Port d'ecoute de la carte
#define CMD_MAX_LEN  64                 // Taille max d'une commande recue
#define REP_MAX_LEN  600                // Taille max de la reponse a SCAN
#define MAX_MESURES  60                 // Nombre max de mesures dans un SCAN
#define ANGLE_MAX    180                // Angle max du servo


int32_t udp_sock = -1;                  // UDP socket handle (-1 = pas encore cree)


extern void  servo_set_angle(int angle); // defini dans main.c
extern float distance_cm(void);          // defini dans main.c
extern int   angle_servo;                // affiche sur l'ecran
extern float distance;                   // affiche sur l'ecran


// SCAN demande par le PC, fait par Thread_Test
int      debut, fin, pas;
NET_ADDR addr_scan;                     // a qui renvoyer le resultat du SCAN
volatile int scan_demande = 0;          // 1 = un SCAN est en attente ou en cours


// Envoie la reponse texte txt a l'expediteur addr (un seul datagramme).
static void repondre(const NET_ADDR *addr, const char *txt) {
  uint32_t n = strlen(txt);
  uint8_t *sendbuf;

  if (udp_sock <= 0 || n == 0) {
    return;
  }
  sendbuf = netUDP_GetBuffer(n);
  if (sendbuf == NULL) {
    return;                             // plus de memoire : reponse perdue, le client renverra
  }
  memcpy(sendbuf, txt, n);
  netUDP_Send(udp_sock, addr, sendbuf, n);
}


// Appelee par la pile reseau a chaque datagramme recu.
// Commandes : "ANGLE a", "DIST", "SCAN debut fin pas".
uint32_t udp_cb_func(int32_t socket, const NET_ADDR *addr, const uint8_t *buf, uint32_t len) {
  char     cmd[CMD_MAX_LEN];
  uint32_t i;                           // uint32_t pour comparer avec len sans warning
  int      a;
  char     reste;                       // sert a detecter du texte en trop
  char     tab[20];

  (void)socket;

  // Commande trop longue : on refuse
  if (len >= CMD_MAX_LEN) {
    repondre(addr, "ERR commande trop longue\n");
    return (0);
  }

  // Copie du datagramme dans une chaine C terminee par '\0'
  // (on s'arrete au \r ou au \n de fin de ligne)
  for (i = 0; i < len && buf[i] != '\r' && buf[i] != '\n'; i++) {
    cmd[i] = (char)buf[i];
  }
  cmd[i] = '\0';

  // Un SCAN est en cours : le servo est occupe
  if (scan_demande == 1) {
    repondre(addr, "ERR SCAN en cours\n");
    return (0);
  }

  // ANGLE
  if (strncmp(cmd, "ANGLE", 5) == 0) {
    if (sscanf(cmd, "ANGLE %d %c", &a, &reste) != 1) {
      repondre(addr, "ERR format\n");
    } else if (a < 0 || a > ANGLE_MAX) {
      repondre(addr, "ERR angle hors plage\n");
    } else {
      servo_set_angle(a);
      angle_servo = a;
      repondre(addr, "OK\n");
    }
  }

  // DIST
  else if (strcmp(cmd, "DIST") == 0) {
    distance = distance_cm();
    if (distance < 0) {
      repondre(addr, "DIST TIMEOUT\n");
    } else {
      sprintf(tab, "DIST %.1f\n", distance);
      repondre(addr, tab);
    }
  }

  // SCAN debut fin pas
  else if (strncmp(cmd, "SCAN", 4) == 0) {
    if (sscanf(cmd, "SCAN %d %d %d %c", &debut, &fin, &pas, &reste) != 3) {
      repondre(addr, "ERR format\n");
    } else if (debut < 0 || fin > ANGLE_MAX || debut > fin || pas <= 0) {
      repondre(addr, "ERR SCAN hors plage\n");
    } else if ((fin - debut) / pas + 1 > MAX_MESURES) {
      repondre(addr, "ERR trop de mesures\n");
    } else {
      addr_scan = *addr;                // retenir a qui repondre
      scan_demande = 1;                 // Thread_Test fera le balayage
    }
  }


  else {
    repondre(addr, "ERR COMMANDE inconnue\n");
  }

  return (0);
}


// Appelee toutes les 100 ms par Thread_Test (main.c).
// Fait le balayage si un SCAN a ete demande (trop long pour udp_cb_func).
void faire_scan(void) {
  int  a;
  char ligne[20];
  static char rep[REP_MAX_LEN];         // static : trop gros pour la pile de la tache

  if (scan_demande == 0) {
    return;                             // pas de SCAN demande
  }

  rep[0] = '\0';                        // reponse vide au depart
  servo_set_angle(debut);
  osDelay(500);                         // aller a l'angle de depart

  for (a = debut; a <= fin; a = a + pas) {
    servo_set_angle(a);
    angle_servo = a;
    osDelay(200);                       // stabilisation (et > 60 ms entre 2 mesures)
    distance = distance_cm();

    if (distance < 0) {
      sprintf(ligne, "%d TIMEOUT\n", a);
    } else {
      sprintf(ligne, "%d %.1f\n", a, distance);
    }
    strcat(rep, ligne);                 // ajouter la ligne a la reponse
  }
  strcat(rep, "END\n");

  repondre(&addr_scan, rep);            // tout en un seul datagramme
  scan_demande = 0;                     // pret pour un autre SCAN
}


// Envoi spontane vers un client (non utilise pour l'instant).
void send_udp_data(void) {

  if (udp_sock > 0) {
    /* Exemple
    // IPv4 address: 192.168.0.1
    NET_ADDR addr = { NET_ADDR_IP4, 2000, 192, 168, 0, 1 };
    uint8_t *sendbuf;

    sendbuf = netUDP_GetBuffer(2);
    if (sendbuf != NULL) {
      sendbuf[0] = 0x01;
      sendbuf[1] = 0xAA;
      netUDP_Send(udp_sock, &addr, sendbuf, 2);
    }
    */
  }
}


// Initialise la pile reseau, cree le socket et ouvre le port UDP_PORT.
void Init_Ethernet(void) {

  netInitialize();

  // Creation du socket UDP et ouverture du port 5000
  udp_sock = netUDP_GetSocket(udp_cb_func);
  if (udp_sock > 0) {
    if (netUDP_Open(udp_sock, UDP_PORT) != netOK) {
      netUDP_ReleaseSocket(udp_sock);   // echec : on libere le socket
      udp_sock = -1;
    }
  }
}
//! [code_UDP_Socket]
